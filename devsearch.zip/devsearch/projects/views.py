from multiprocessing import context
from django.shortcuts import render

from django.http import HttpResponse

projectsList =[
     {
       'id' : '1',
       'title': "Ecommerce website",
       'description':'Fully functional ecommerce website'
     },
     {
       'id':'2',
       'title':"Protfolio Website",
       'description':'This was a project where I built out my portfolio website'
     },
     {
       'id':'3',
       'title':"social network",
       'description':' Awesome open source project I am still working'
     }
]


def projects(request):
  page='projects'
  number=10
  context={'page':page, 'number':number, 'projects':projectsList}
  return render(request, 'projects/projects.html', context)
def project(request, pk):
  projectObj = None
  for i in projectsList:
    if i['id'] == pk:
      projectObj = i
  return render(request ,'projects/single-projects.html',{'project':projectObj})
  
